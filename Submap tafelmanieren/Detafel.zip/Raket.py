print('Raket lancering van 30 tot 0!')
for x in range(30,0,-1):
    print(x)
print('EN WE LANCEREN!')