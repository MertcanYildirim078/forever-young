
tafel = int(input('Vul de tafel in: '))
for x  in range(0,11):
    a = x * tafel
    print(a)