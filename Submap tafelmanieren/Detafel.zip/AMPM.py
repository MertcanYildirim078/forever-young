for x in range(0,13):
    print(x, ' AM')
for y in range(1,12):
    print(y, ' PM')